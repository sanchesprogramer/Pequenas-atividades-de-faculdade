import java.sql.*;
public class ConnectionFactory{
    String url = System.getenv("URL");
    String user = System.getenv("USERNAME");
    String pass = System.getenv("PASSWORD");
    
    private static ConnectionFactory connectionFactory = null;
    public Connection getConnection() throws SQLException{
      Connection conexao = null;
      conexao = DriverManager.getConnection(url, user, pass);
      return conexao;
    }
  public static ConnectionFactory getInstance(){
    if(connectionFactory == null){
      connectionFactory = new ConnectionFactory();
    }
    return connectionFactory;
  }
}