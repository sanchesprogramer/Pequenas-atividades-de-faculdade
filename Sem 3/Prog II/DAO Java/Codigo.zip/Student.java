public class Student{
  int rollNo;
  String Name;
  String TIA;
  String Course;
public Student(){
  
}
  public Student(int x, String y, String z, String a){
    this.rollNo = x;
    this.Name = y;
    this.TIA = z;
    this.Course = a;
  }
public int getRollNo(){
  return this.rollNo;
}
public String getName(){
  return this.Name;
}
public String getTIA(){
  return this.TIA;
}
  public String getCourse(){
  return this.Course;
}
public void setRollNo(int x){
  this.rollNo = x;
}
public void setName(String x){
  this.Name = x;
}
public void setTIA(String x){
  this.TIA = x;
}
public void setCourse(String x){
  this.Course = x;
}
}