import java.sql.*;
public class Main{
  public static void main(String[] args){
    StudentJDBCDAO student = new StudentJDBCDAO();
    Student a = new Student();
    a.setName("Raphael");
    a.setRollNo(2);
    a.setTIA("32213949");
    a.setCourse("CC");
    student.findAll();
    //student.add(a);
  }
}