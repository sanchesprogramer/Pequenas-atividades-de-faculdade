//Gabriel William Ribeiro Pauleti, TIA: 32213948
//Felipe de Almeida Parreira, TIA: 32211041

import java.sql.*;
import java.util.*;
public class StudentJDBCDAO{
  Connection conexao = null;
  PreparedStatement stm = null;
  ResultSet rs = null;
  public StudentJDBCDAO(){
    
  }
  private Connection getConnection() throws SQLException{
    Connection conexao;
    conexao = ConnectionFactory.getInstance().getConnection();
    return conexao;
  }
  public void add(Student x) throws SQLException {
  try{
    //Connection conexao = DriverManager.getConnection(url, user, pass);
    conexao = getConnection();
    String sql = "INSERT INTO student(RollNo, Name, TIA, Course) VALUES (?,?,?,?)";
    PreparedStatement stm = conexao.prepareStatement(sql);
    stm.setInt(1 , x.getRollNo());
    stm.setString(2, x.getName());
    stm.setString(3, x.getTIA());
    stm.setString(4, x.getCourse());
    stm.executeUpdate();
    System.out.println("Data added successfully!");
    stm.close();
    conexao.close();
  }catch(SQLException e){
    e.printStackTrace();
  }
  
  }

public void update(Student x) throws SQLException{
  try{
    String sql = "UPDATE student SET Name=? WHERE RollNo=?";
    conexao = getConnection();    
    PreparedStatement stm = conexao.prepareStatement(sql);
    stm.setInt(1, x.getRollNo());
    stm.setString(2, x.getName());
    stm.setString(3, x.getTIA());
    stm.setString(4, x.getCourse());
    int rs = stm.executeUpdate();
    System.out.println("Data updated successfully!");
    stm.close();
    conexao.close();
  }catch(SQLException e){
    e.printStackTrace();
  }
}
    public void delete(int rollNo){
      try{
        String sql = "DELETE FROM student WHERE RollNo=?";
        conexao = getConnection();
        stm = conexao.prepareStatement(sql);
        stm.setInt(1, rollNo);
        stm.executeUpdate();
        System.out.println("Data deleted succesfully!");
        stm.close();
        conexao.close();
      }catch(SQLException e){
        e.printStackTrace();
      }
      }
  public void findAll(){
    try{
      String sql = "SELECT * FROM student";
      conexao = getConnection();
      stm = conexao.prepareStatement(sql);
      rs = stm.executeQuery();
      while (rs.next()){
        System.out.println("Roll No " + rs.getInt("RollNo") + ", Name " + rs.getString("Name") + ", TIA " + rs.getString("TIA") + ", Course " + rs.getString("Course"));
      }
      rs.close();
      stm.close();
      conexao.close();
    }catch(SQLException e){
      e.printStackTrace();
    }
  }
}
    
    