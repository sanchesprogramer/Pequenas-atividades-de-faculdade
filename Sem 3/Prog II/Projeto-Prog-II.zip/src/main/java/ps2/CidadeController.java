package ps2;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;


@RestController
@RequestMapping(value = "/api")
public class CidadeController {
  @Autowired
  private CidadeRepository repository;

  // @RequestMapping(value = "/alunos", method = RequestMethod.GET)
  @GetMapping("/cidades")
  public List<Cidade> getCidades() {
    return repository.findAll();
  }
  
 // @RequestMapping(value = "/alunos", method = RequestMethod.POST)
  @PostMapping("/cidades")
  public Cidade postCidade(@RequestBody Cidade cidade) {
    return repository.save(cidade);
  }
  

     @GetMapping("/cidades/{id}")
    public ResponseEntity<Cidade> GetById(@PathVariable(value = "id") long id)
    {
        Optional<Cidade> cidade = repository.findById(id);
        if(cidade.isPresent())
            return new ResponseEntity<Cidade>(cidade.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
   @GetMapping("/cidades/populacao/{populacao}")
    public ResponseEntity<Cidade> getByPopulacao(@PathVariable(value = "populacao") long populacao) {
        Optional<Cidade> cidade = repository.findByPopulacao(populacao);
        if (cidade.isPresent()) {
            return new ResponseEntity<>(cidade.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
  
  
  @PutMapping("/cidades/{id}")
    public ResponseEntity<Cidade> Put(@PathVariable(value = "id") long id, @RequestBody Cidade newCidade)
    {
        Optional<Cidade> oldCidade = repository.findById(id);
        if(oldCidade.isPresent()){
            Cidade cidade = oldCidade.get();
            cidade.setNome(newCidade.getNome());
            cidade.setEstado(newCidade.getEstado());
            cidade.setPopulacao(newCidade.getPopulacao());
            cidade.setPais(newCidade.getPais());
            repository.save(cidade);
            return new ResponseEntity<Cidade>(cidade, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  @RequestMapping(value = "/cidades/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") long id)
    {
        Optional<Cidade> cidade = repository.findById(id);
        if(cidade.isPresent()){
            repository.delete(cidade.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
