package ps2;

import javax.persistence.*;

@Entity
@Table(name="paises")
  public class Pais{
  @Id
  long id;
  String nome;
  String continente;
  long populacao;
    public Pais() {
    nome = "";
    continente = "";
  }
  public Pais(String nome, long id, String continente, long populacao){
    this.nome = nome;
    this.id = id;
    this.continente = continente;
    this.populacao = populacao;
  }
    
  public void setId(long id) {
    this.id = id;
  }
  
  public long getId() {
    return id;
  }
  
  public void setNome(String nome) {
    this.nome = nome;
  }
  
  public String getNome() {
    return this.nome;
  }
  
  public void setContinente(String continente) {
    this.continente = continente;
  }
  
  public String getContinente() {
    return this.continente;
  }
  
  public void setPopulacao(long populacao) {
    this.populacao = populacao;
  }
  
  public long getPopulacao() {
    return this.populacao;
  }
}
 