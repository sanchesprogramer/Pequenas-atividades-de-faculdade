package ps2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

public interface CidadeRepository extends JpaRepository<Cidade, Long> {
   Optional<Cidade> findByPopulacao(long populacao);
}
