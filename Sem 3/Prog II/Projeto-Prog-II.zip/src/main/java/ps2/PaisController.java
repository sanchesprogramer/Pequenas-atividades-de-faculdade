package ps2;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;


@RestController
@RequestMapping(value = "/api")
public class PaisController {
  @Autowired
  private PaisRepository repository;

  // @RequestMapping(value = "/alunos", method = RequestMethod.GET)
  @GetMapping("/paises")
  public List<Pais> getPaises() {
    return repository.findAll();
  }

 // @RequestMapping(value = "/alunos", method = RequestMethod.POST)
  @PostMapping("/paises")
  public Pais postPais(@RequestBody Pais pais) {
    return repository.save(pais);
  }

     @GetMapping("/paises/{id}")
    public ResponseEntity<Pais> GetById(@PathVariable(value = "id") long id)
    {
        Optional<Pais> pais = repository.findById(id);
        if(pais.isPresent())
            return new ResponseEntity<Pais>(pais.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  
   @GetMapping("/paises/populacao/{populacao}")
    public ResponseEntity<Pais> getByPopulacao(@PathVariable(value = "populacao") long populacao) {
        Optional<Pais> pais = repository.findByPopulacao(populacao);
        if (pais.isPresent()) {
            return new ResponseEntity<>(pais.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
  
  @PutMapping("/paises/{id}")
    public ResponseEntity<Pais> Put(@PathVariable(value = "id") long id, @RequestBody Pais newPais)
    {
        Optional<Pais> oldPais = repository.findById(id);
        if(oldPais.isPresent()){
            Pais pais = oldPais.get();
            pais.setNome(newPais.getNome());
            pais.setContinente(newPais.getContinente());
            pais.setPopulacao(newPais.getPopulacao());
            repository.save(pais);
            return new ResponseEntity<Pais>(pais, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  @RequestMapping(value = "/paises/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") long id)
    {
        Optional<Pais> pais = repository.findById(id);
        if(pais.isPresent()){
            repository.delete(pais.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
