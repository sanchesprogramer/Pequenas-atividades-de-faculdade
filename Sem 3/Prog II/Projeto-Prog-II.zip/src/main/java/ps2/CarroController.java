package ps2;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;


@RestController
@RequestMapping(value = "/api")
public class CarroController {
  @Autowired
  private CarroRepository repository;

  // @RequestMapping(value = "/alunos", method = RequestMethod.GET)
  @GetMapping("/carros")
  public List<Carro> getCarros() {
    return repository.findAll();
  }

 // @RequestMapping(value = "/alunos", method = RequestMethod.POST)
  @PostMapping("/carros")
  public Carro postCarro(@RequestBody Carro carro) {
    return repository.save(carro);
  }

     @GetMapping("/carros/{id}")
    public ResponseEntity<Carro> GetById(@PathVariable(value = "id") long id)
    {
        Optional<Carro> carro = repository.findById(id);
        if(carro.isPresent())
            return new ResponseEntity<Carro>(carro.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
   @GetMapping("/carros/ano/{ano}")
    public ResponseEntity<Carro> getByAno(@PathVariable(value = "ano") long ano) {
        Optional<Carro> carro = repository.findByAno(ano);
        if (carro.isPresent()) {
            return new ResponseEntity<>(carro.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
  
  @PutMapping("/carros/{id}")
    public ResponseEntity<Carro> Put(@PathVariable(value = "id") long id, @RequestBody Carro newCarro)
    {
        Optional<Carro> oldCarro = repository.findById(id);
        if(oldCarro.isPresent()){
            Carro carro = oldCarro.get();
            carro.setMarca(newCarro.getMarca());
            carro.setModelo(newCarro.getModelo());
            carro.setAno(newCarro.getAno());
            carro.setCategoria(newCarro.getCategoria());
            repository.save(carro);
            return new ResponseEntity<Carro>(carro, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  @RequestMapping(value = "/carros/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") long id)
    {
        Optional<Carro> carro = repository.findById(id);
        if(carro.isPresent()){
            repository.delete(carro.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
