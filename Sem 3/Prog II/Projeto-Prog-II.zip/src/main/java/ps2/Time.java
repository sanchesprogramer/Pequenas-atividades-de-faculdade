package ps2;

import javax.persistence.*;

@Entity
@Table(name="times")
  public class Time{
  @Id
  long id;
  String nome;
  long fundacao;
  String cidade;
  String estado;
    public Time() {
    nome = "";
    cidade = "";
    estado = "";
  }
  public Time(String nome, long id, String cidade, long fundacao, String estado){
    this.nome = nome;
    this.id = id;
    this.cidade = cidade;
    this.fundacao = fundacao;
    this.estado = estado;
  }
    
  public void setId(long id) {
    this.id = id;
  }
  
  public long getId() {
    return id;
  }
  
  public void setNome(String nome) {
    this.nome = nome;
  }
  
  public String getNome() {
    return this.nome;
  }
  
  public void setCidade(String cidade) {
    this.cidade = cidade;
  }
  
  public String getCidade() {
    return this.cidade;
  }
  public void setEstado(String estado) {
    this.estado = estado;
  }
  
  public String getEstado() {
    return this.estado;
  }
  
  public void setFundacao(long fundacao) {
    this.fundacao = fundacao;
  }
  
  public long getFundacao() {
    return this.fundacao;
  }
}
 