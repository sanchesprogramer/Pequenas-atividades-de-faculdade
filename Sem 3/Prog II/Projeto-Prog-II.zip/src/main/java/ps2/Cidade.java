package ps2;

import javax.persistence.*;

@Entity
@Table(name="cidades")
  public class Cidade{
  @Id
  long id;
  String nome;
  String pais;
  String estado;
  long populacao;
    public Cidade() {
    nome = "";
    pais = "";
    estado = "";
    
  }
  public Cidade(String nome, long id, String pais, long populacao, String estado){
    this.nome = nome;
    this.id = id;
    this.pais = pais;
    this.populacao = populacao;
    this.estado = estado;
  }
    
  public void setId(long id) {
    this.id = id;
  }
  
  public long getId() {
    return id;
  }
  
  public void setNome(String nome) {
    this.nome = nome;
  }
  
  public String getNome() {
    return this.nome;
  }
  
  public void setPais(String pais) {
    this.pais = pais;
  }
  
  public String getPais() {
    return this.pais;
  }
  
  public void setPopulacao(long populacao) {
    this.populacao = populacao;
  }
  
  public long getPopulacao() {
    return this.populacao;
  }
  public void setEstado(String estado) {
    this.estado = estado;
  }
  
  public String getEstado() {
    return this.estado;
  }
}
 