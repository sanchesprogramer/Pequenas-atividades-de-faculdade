package ps2;

import javax.persistence.*;

@Entity
@Table(name="carros")
  public class Carro{
  @Id
  long id;
  String modelo;
  long ano;
  String marca;
  String categoria;
    public Carro() {
    modelo = "";
    marca = "";
    categoria = "";
  }
  public Carro(String modelo, long id, String marca, long ano, String categoria){
    this.modelo = modelo;
    this.id = id;
    this.marca = marca;
    this.ano = ano;
    this.categoria = categoria;
  }
    
  public void setId(long id) {
    this.id = id;
  }
  
  public long getId() {
    return id;
  }
  
  public void setModelo(String modelo) {
    this.modelo = modelo;
  }
  
  public String getModelo() {
    return this.modelo;
  }
  
  public void setMarca(String marca) {
    this.marca = marca;
  }
  
  public String getMarca() {
    return this.marca;
  }
  public void setCategoria(String categoria) {
    this.categoria = categoria;
  }
  
  public String getCategoria() {
    return this.categoria;
  }
  
  public void setAno(long ano) {
    this.ano = ano;
  }
  
  public long getAno() {
    return this.ano;
  }
}
 