package ps2;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;


@RestController
@RequestMapping(value = "/api")
public class TimeController {
  @Autowired
  private TimeRepository repository;

  // @RequestMapping(value = "/alunos", method = RequestMethod.GET)
  @GetMapping("/times")
  public List<Time> getTimes() {
    return repository.findAll();
  }

 // @RequestMapping(value = "/alunos", method = RequestMethod.POST)
  @PostMapping("/times")
  public Time postTime(@RequestBody Time time) {
    return repository.save(time);
  }

     @GetMapping("/times/{id}")
    public ResponseEntity<Time> GetById(@PathVariable(value = "id") long id)
    {
        Optional<Time> time = repository.findById(id);
        if(time.isPresent())
            return new ResponseEntity<Time>(time.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  @GetMapping("/times/fundacao/{fundacao}")
    public ResponseEntity<Time> getByFundacao(@PathVariable(value = "fundacao") long fundacao) {
        Optional<Time> time = repository.findByFundacao(fundacao);
        if (time.isPresent()) {
            return new ResponseEntity<>(time.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
  
  @PutMapping("/times/{id}")
    public ResponseEntity<Time> Put(@PathVariable(value = "id") long id, @RequestBody Time newTime)
    {
        Optional<Time> oldTime = repository.findById(id);
        if(oldTime.isPresent()){
            Time time = oldTime.get();
            time.setNome(newTime.getNome());
            time.setCidade(newTime.getCidade());
            time.setFundacao(newTime.getFundacao());
            time.setEstado(newTime.getEstado());
            repository.save(time);
            return new ResponseEntity<Time>(time, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  @RequestMapping(value = "/times/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") long id)
    {
        Optional<Time> time = repository.findById(id);
        if(time.isPresent()){
            repository.delete(time.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
